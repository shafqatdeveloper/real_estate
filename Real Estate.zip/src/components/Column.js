export const COLUMN = [
  {
    HEADER: "Marla",
    accessor: "marla_row",
  },
  {
    HEADER: "Kanal",
    accessor: "kanal_row",
  },
  {
    HEADER: "Sq. Feet",
    accessor: "sq_feet",
  },
  {
    HEADER: "Sq. Yard",
    accessor: "sq_yard",
  },
];

export const COLUMN_B = [
  {HEADER : "Title",
    accessor:"country"
  },
  {HEADER : "Index",
    accessor:"index"
  },
  {HEADER : "Price/Sq.",
    accessor:"price/sq"
  },
  {HEADER : "price",
    accessor:"price"
  },
  {HEADER : "3m",
    accessor:"month"
  },
]