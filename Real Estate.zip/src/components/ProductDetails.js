import React, { useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { products_data } from './Data'

const ProductDetails = () => {
  const data = products_data;
  const {id} = useParams()
  console.log(id)
 

  return (
<div>
</div>
  )
}

export default ProductDetails